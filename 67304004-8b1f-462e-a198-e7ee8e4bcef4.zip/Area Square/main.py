# Online Python Playground
# Use the online compiler to write, edit & run your Python code
# Create, edit & delete files online

def areaSquare( side ): 
	area = side * side 
	return area 
side = 4
print(areaSquare(side))